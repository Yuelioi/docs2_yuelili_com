# 变换 Transform

## 介绍

在空间中整体移动粒子系统。类似图层的 transform 属性

Inherit Motion 继承运动：一般可以绑定一个空对象，用于控制粒子系统的位置

Anchor XY 轴心点 XY

Anchor Z 轴心点 Z

Position X X 轴位置

Position Y Y 轴位置

Position Z Z 轴位置

Rotation X X 轴旋转

Rotation Y Y 轴旋转

Rotation Z Z 轴旋转

Scale X X 轴缩放：X 位置缩放，粒子大小不变

Scale Y Y 轴缩放：Y 位置缩放，粒子大小不变

Scale Z Z 轴缩放：Z 位置缩放，粒子大小不变

Particles Scale 粒子大小缩放

Particles Opacity 粒子不透明度
