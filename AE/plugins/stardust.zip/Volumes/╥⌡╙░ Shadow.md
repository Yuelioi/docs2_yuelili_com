# 阴影 Shadow

### Shading 阴影

对粒子的阴影进行额外控制。您可以对粒子空间中的灯光进行一些额外的控制，默认情况下，如果启用阴影，则会得到阴影，但是如果要过滤灯光名称并为每个节点应用不同的灯光属性，则可以连接灯光该粒子系统的节点并对其进行微调。

您还可以设置一个环境层以与“矩形”和“纹理”粒子一起使用，要使用此层，请选择一个反射层并设置其不透明度。

#### Shading On／Of 阴影开关

#### Starting With 图层选择

#### Amount 强度

#### Diffuse 漫射

#### Specular 高光

#### Specular Shine 镜面光泽

#### Reflection Texture 反射贴图

#### Reflection 反射
