# 体积光 Volumetric

### Volumetric 体积光

将 3D 体积照明添加到场景中。

#### On／ Off 开关

#### Starting With 选择图层

#### Amount 强度

#### Distribution 分布

#### Color 颜色

#### Hotspot Brightness 热点亮度

#### Hotspot Size 热点大小

#### Decay 衰减

#### Contrast 对比

#### Shimmer Amount 闪光强度

#### Shimmer Size 闪光大小

#### Shimmer Phase 闪光阶段

#### Simmer Mix 闪光混合

#### Shimmer World 全局闪光

#### Transfer Mode 混合模式

- Normal 正常
- Add 叠加

### Source 源

#### Source Type 源类型

- Layer 图层
- Layers Filter 图层过滤
- OBJ
- Color Graph 颜色图表
- Over Life Graph 跟随生命图表
- Layers Set 图层设置

#### Output 输出

#### Properties 属性

- Layer 图层
- Starting With 图层选择
- File Name 文件名
- Origin XY 起点 XY
- Origin Z 起点 Z
- Angle X 角度 X
- Angle Y 角度 Y
- Angle Z 角度 Z
- Size 大小
- Center 中心
- Normalize Scale 正常大小
- Load Sequence 夹在序列
- Enable／Disable Params 启用／禁用参数
- Color Graph 颜色图表
- Over Life Graph 跟随生命图表
- Layers Set 图层设置
