# OMCollection 对象

## 输出模块集

app.project.renderQueue.items.outputModules

描述

输出模块集（OMCollection）在渲染队列中包含所有输出模块。该集合提供对输出模块（OutputModule）对象的访问，但不提供任何其他功能。集合中的第一个输出模块索引为 1。

父级关系：输出模块集是 Collection 对象的子类。Collection 的方法和属性均可用。
