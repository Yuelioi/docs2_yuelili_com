# PlaceholderSource 占位符源

## 占位符源对象

app.project.item(index).mainSource  
app.project.item(index).proxySource

描述

占位符源对象（PlaceholderSource）对象描述了占位符的素材来源。

父级关系：占位符源对象是素材源（footageSource）对象的子类。因此素材源（FootageSource）方法和属性均可用。它本身没有单独的方法或属性。
