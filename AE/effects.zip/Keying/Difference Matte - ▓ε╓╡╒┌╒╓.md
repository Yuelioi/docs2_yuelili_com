# Difference Matte - 差值遮罩

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-Difference_Matte.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-Difference_Matte_cn.png)
