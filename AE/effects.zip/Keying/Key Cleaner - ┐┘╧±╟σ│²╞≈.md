# Key Cleaner - 抠像清除器

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-Key_Cleaner.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-Key_Cleaner_cn.png)
