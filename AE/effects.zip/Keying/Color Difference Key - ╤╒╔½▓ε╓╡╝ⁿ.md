# Color Difference Key - 颜色差值键

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-Color_Difference_Key.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-Color_Difference_Key_cn.png)
