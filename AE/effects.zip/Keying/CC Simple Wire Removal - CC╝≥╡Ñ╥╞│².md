# CC Simple Wire Removal - CC简单移除

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-CC_Simple_Wire_Removal.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-CC_Simple_Wire_Removal_cn.png)
