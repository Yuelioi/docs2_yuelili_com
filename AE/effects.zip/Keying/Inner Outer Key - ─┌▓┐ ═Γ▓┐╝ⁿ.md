# Inner Outer Key - 内部 外部键

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-Inner/Outer_Key.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-Inner/Outer_Key_cn.png)
