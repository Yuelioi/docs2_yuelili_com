# Color Range - 颜色范围

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-Color_Range.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Keying-Color_Range_cn.png)
