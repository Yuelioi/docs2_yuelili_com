# CC Burn Film - CC胶片电影

## 简述

## 效果展示

![](https://cdn.yuelili.com/20211231161959.png)

## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=66&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Stylize-CC_Burn_Film.png)

## 参数详解

### Burn 灼烧

范围 0 ～ 100，控制灼烧点的大小。

### Center 中心

控制灼烧产生的中心位置。

### Random Seed 随机种子

随机形成新灼烧样式。

## 案例

作为灰白图使用

与 CC Glass 配合，形成液状扭曲过度（教程 1:15~）

![](https://cdn.yuelili.com/20211231162412.png)
