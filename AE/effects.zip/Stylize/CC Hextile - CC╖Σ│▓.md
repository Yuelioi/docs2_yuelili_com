# CC Hextile - CC蜂巢

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Stylize-CC_Hextile.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Stylize-CC_Hextile_cn.png)
