# CC Repe Tile - CC瓷砖

## 简述

跟动态拼贴差不多，只不过属性是像素，而不是百分比。

其次，多了些预设样式：水平、垂直、蜂窝、随机什么的。（都是排列的风格）

## 效果展示

![](https://cdn.yuelili.com/20211228152739.png)

## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=12&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Stylize-CC_Repe_Tile.png)

## 参数详解

### Blend Borders 混合边框

字幕意思，接缝处混合下

| 不勾选                                          | 勾选 |
| ----------------------------------------------- | ---- |
| ![](https://cdn.yuelili.com/20211228153209.png) |

![](https://cdn.yuelili.com/20211228153520.png)

## 案例
