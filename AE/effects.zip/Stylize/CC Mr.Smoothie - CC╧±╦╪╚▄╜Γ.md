# CC Mr.Smoothie - CC像素溶解

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Stylize-CC_Mr.Smoothie.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Stylize-CC_Mr.Smoothie_cn.png)
