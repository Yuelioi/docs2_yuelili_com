# CC Threshold Rgb - CC阈值RGB

## 简述

基于 RGB 分割颜色，而阈值效果是基于亮度分割成黑白图

## 效果展示

![](https://cdn.yuelili.com/20211228163625.png)

只过滤红色

![](https://cdn.yuelili.com/20211228163741.png)

## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=17&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Stylize-CC_Threshold_Rgb.png)

## 参数详解

## 案例

AK 大神 在 007.去除面部瑕疵中，用本效果获得人脸抠像

![](https://cdn.yuelili.com/20211228164012.png)
