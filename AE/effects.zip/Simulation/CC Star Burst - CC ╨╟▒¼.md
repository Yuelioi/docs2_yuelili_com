# CC Star Burst - CC 星爆

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Simulation-CC_Star_Burst.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Simulation-CC_Star_Burst_cn.png)
