# CC Mr.Mercury - CC 水银滴落

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Simulation-CC_Mr.Mercury.png)

## 参数详解

## 案例
