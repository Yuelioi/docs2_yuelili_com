# CC Particle Systems Ⅱ - CC 粒子系统Ⅱ

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Simulation-CC_Particle_Systems_Ⅱ.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Simulation-CC_Particle_Systems_Ⅱ_cn.png)
