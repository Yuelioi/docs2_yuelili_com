# Particle Playground - 粒子运动场

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Simulation-Particle_Playground.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Simulation-Particle_Playground_cn.png)
