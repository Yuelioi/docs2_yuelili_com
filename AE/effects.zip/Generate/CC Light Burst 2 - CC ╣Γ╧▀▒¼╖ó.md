# CC Light Burst 2 - CC 光线爆发

## 简述

顾名思义，就是让图片中的亮的地方爆出来

![](https://cdn.yuelili.com/20211228013019.png)

![](https://cdn.yuelili.com/20211228013007.png)

## 效果展示

![](https://cdn.yuelili.com/20211228013636.png) |
![](https://cdn.yuelili.com/20211228013554.png)  
---|---  
![](https://cdn.yuelili.com/20211228013619.png) |
![](https://cdn.yuelili.com/20211228013434.png)  
|

## 教程

## 中英日对照

| CC Light Burst 2.5 | CC 光线爆发 2.5 | CC Light Burst 2.5 |          |      |            |
| ------------------ | --------------- | ------------------ | -------- | ---- | ---------- |
| Center             | 中心            | 中心               |          |      |            |
| Intensity          | 强度            | 密度               |          |      |            |
| Ray Length         | 光线强度        |                    |          |      |            |
| Burst              | 爆发            |                    | Straight | 直线 | ストレート |
|                    |                 |                    | Fade     | 衰减 | 減衰       |
|                    |                 |                    | Center   | 中心 | 中心       |
| Halo Alpha         | 光晕 Alpha      |                    |          |      |            |
| Set Color          | 设置颜色        | カラーを設定       |          |      |            |
| Color              | 颜色            | カラー             |          |      |            |

## 参数详解

## 案例
