# Ellipse - 椭圆

## 简述

可绘制椭圆。感觉用处不是很大，可调参数也很少。如果想弄个发光椭圆环可以玩一下

此效果适用于 8-bpc、16-bpc 和 32-bpc 颜色。

## 效果展示

![](https://cdn.yuelili.com/20211230153337.png)

## 教程 5.50~

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=44&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Generate-Ellipse.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Generate-Ellipse_cn.png)

## 参数详解

## 案例
