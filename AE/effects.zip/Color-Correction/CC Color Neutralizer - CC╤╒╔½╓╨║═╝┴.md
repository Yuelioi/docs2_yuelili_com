# CC Color Neutralizer - CC颜色中和剂

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-CC_Color_Neutralizer.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-CC_Color_Neutralizer_cn.png)
