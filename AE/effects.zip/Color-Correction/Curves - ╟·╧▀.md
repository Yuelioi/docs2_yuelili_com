# Curves - 曲线

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Curves.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Curves_cn.png)
