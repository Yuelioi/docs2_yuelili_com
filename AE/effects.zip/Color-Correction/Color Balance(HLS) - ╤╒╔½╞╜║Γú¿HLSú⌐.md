# Color Balance(HLS) - 颜色平衡（HLS）

## 简述

## 效果展示

## 教程

## 中英日对照

![](<https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Color_Balance(HLS).png>)![](<https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Color_Balance(HLS)_cn.png>)
