# Auto Color - 自动颜色

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Auto_Color.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Auto_Color_cn.png)
