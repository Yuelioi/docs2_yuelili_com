# Shadow Highlight - 阴影 高光

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Shadow/Highlight.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Shadow/Highlight_cn.png)
