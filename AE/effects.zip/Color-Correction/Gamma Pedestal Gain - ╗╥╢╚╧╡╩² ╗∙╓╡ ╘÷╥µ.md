# Gamma Pedestal Gain - 灰度系数 基值 增益

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Gamma/Pedestal/Gain.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Gamma/Pedestal/Gain_cn.png)
