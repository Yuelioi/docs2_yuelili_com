# Ps Arbitrary Map - PS任意映射

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Ps_Arbitrary_Map.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Color-Ps_Arbitrary_Map_cn.png)
