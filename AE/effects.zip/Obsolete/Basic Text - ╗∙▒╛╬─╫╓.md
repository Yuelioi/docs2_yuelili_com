# Basic Text - 基本文字

## 简述

为了适配旧版，没啥用。现在可以直接使用文字图层

如果您正在处理在 After Effects
的旧版本中创建的项目，并且“基本文字”效果应用于一个或多个图层，那么您可以继续使用“基本文字”效果；否则，应使用文本图层来更好地控制文本格式和文本动画。（请参阅创建和编辑文本图层。）

“基本文字”效果将文本置于现有图层上，这与在文本图层上创建的文本或者在 Adobe Photoshop 或 Adobe Illustrator
中创建的导入文本不同，后两种文本将自成图层。

此效果适用于 8-bpc 颜色。

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Obsolete-Basic_Text.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Obsolete-Basic_Text_cn.png)

## 参数详解

## 案例
