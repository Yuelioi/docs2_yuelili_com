# Spill Suppressor - 溢出抑制

## 简述

溢出抑制器效果可从具有已抠出屏幕的图像中移除主色的痕迹。通常，溢出抑制器效果用于从图像边缘移除溢出的主色。溢出是光照从屏幕反射到主体所致。

## 效果展示

比如紫色背景扣的狗狗边缘有紫色，抑制一下就好很多了

![](https://cdn.yuelili.com/20220102224709.png)

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Obsolete-Spill_Suppressor.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Obsolete-Spill_Suppressor_cn.png)

## 参数详解

## 案例
