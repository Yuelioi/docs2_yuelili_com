# Reduce Interlace Flicker - 减少交错闪烁

## 简述

现在很少有隔行素材了，故过时

减少隔行闪烁在处理隔行素材时很有用。隔行闪烁通常是由隔行镜头中可见的条纹引起的。它可以在您的视频上制作一个不吸引人的图案。

为了说明这一点并展示效果的工作原理，我创建了这种黑白条纹图案。  
通过转到效果，模糊和锐化，减少隔行闪烁来应用效果。唯一可调整的  
属性是柔软度。增加柔和度会应用垂直方向模糊来柔化水平  
边缘，这将降低线条的对比度，从而减少闪烁。

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Obsolete-Reduce_Interlace_Flicker.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Obsolete-Reduce_Interlace_Flicker_cn.png)

## 参数详解

## 案例
