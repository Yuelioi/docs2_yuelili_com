# Checkbox Control - 复选框控制

## 简述

通过把表达式链接到此控件，可以使用此控件轻松控制一个布尔控件。

勾选会返回 1，不勾选会返回 0

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Expression-Controls-Checkbox_Control.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Expression-Controls-Checkbox_Control_cn.png)

## 参数详解

## 案例
