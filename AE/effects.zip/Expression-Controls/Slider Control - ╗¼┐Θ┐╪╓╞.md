# Slider Control - 滑块控制

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Expression-Controls-Slider_Control.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Expression-Controls-Slider_Control_cn.png)
