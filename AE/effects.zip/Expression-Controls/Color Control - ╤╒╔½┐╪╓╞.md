# Color Control - 颜色控制

## 简述

通过把表达式链接到此控件，可以使用此控件轻松控制目标颜色。

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Expression-Controls-Color_Control.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Expression-Controls-Color_Control_cn.png)

## 参数详解

## 案例
