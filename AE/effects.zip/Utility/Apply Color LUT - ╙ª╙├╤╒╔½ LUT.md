# Apply Color LUT - 应用颜色 LUT

## 简述

自行设置 Lut 颜色

## 效果展示

没用过！

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Utility-Apply_Color_LUT.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Utility-Apply_Color_LUT_cn.png)

## 参数详解

## 案例
