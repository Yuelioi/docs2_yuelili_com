# Turbulent Noise - 湍流杂色

## 简述

湍流杂色跟[分形杂色](https://www.yuelili.com/docs/ae-effect/fractal-noise/)效果完全一样。区别在于湍流杂色渲染更快，但是没有循环控件。

如果要循环就分形杂色，不然湍流杂色。

## 效果展示

## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=10&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

## 参数详解

## 案例
