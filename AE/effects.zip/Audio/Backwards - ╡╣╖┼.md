# Backwards - 倒放

## 简述

音频从后往前放！

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Audio-Backwards.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Audio-Backwards_cn.png)

## 参数详解

## 案例
