# Stero Mixer - 立体声混合器

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Audio-Stero_Mixer.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Audio-Stero_Mixer_cn.png)
