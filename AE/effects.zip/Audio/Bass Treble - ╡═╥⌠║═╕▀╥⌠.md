# Bass Treble - 低音和高音

## 简述

可增减音频的低频（低音）或高频（高音）。为增强控制，需使用参数均衡效果。

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Audio-Bass_Treble.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Audio-Bass_Treble_cn.png)

## 参数详解

## 案例
