# CC Line Sweep - CC线扫描

## 简述

锯齿状的线扫描，可以控制他的高宽。

## 效果展示

![](https://cdn.yuelili.com/20220103202441.png)

## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=62&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Transition-CC_Line_Sweep.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Transition-CC_Line_Sweep_cn.png)

| CC Line Sweep | CC 线扫描 | CC Line Sweep |                |          |            |
| ------------- | --------- | ------------- | -------------- | -------- | ---------- |
|               |           |               | Completion     | 完成     | 完了       |
|               |           |               | Direction      | 方向     | 方向       |
|               |           |               | Thickness      | 厚度     | 太さ       |
|               |           |               | Slant          | 倾斜     | 歪曲       |
|               |           |               | Flip Direction | 反转方向 | 方向を反転 |

## 参数详解

## 案例
