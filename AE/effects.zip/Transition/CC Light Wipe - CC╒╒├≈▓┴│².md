# CC Light Wipe - CC照明擦除

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Transition-CC_Light_Wipe.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Transition-CC_Light_Wipe_cn.png)
