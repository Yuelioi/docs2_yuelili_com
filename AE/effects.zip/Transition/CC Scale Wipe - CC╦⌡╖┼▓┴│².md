# CC Scale Wipe - CC缩放擦除

## 简述

## 效果展示



## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=64&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Transition-CC_Scale_Wipe.png)

| Stretch   | 扩展 | Escape |
| --------- | ---- | ------ |
| Center    | 中心 | 中心   |
| Direction | 方向 | 方向   |

## 参数详解

扩展：拉伸值

中心：过渡的中心点

## 案例

![](https://cdn.yuelili.com/20211227131432.gif)
