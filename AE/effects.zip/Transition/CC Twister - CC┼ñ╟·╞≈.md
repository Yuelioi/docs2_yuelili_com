# CC Twister - CC扭曲器

## 简述

基于轴线的一种，夸张的、怪怪的扭曲

## 效果展示

![](https://cdn.yuelili.com/20220103204534.png)

## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=80&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Transition-CC_Twister.png)

| Completion | 完成 | 完了         |
| ---------- | ---- | ------------ |
| Backside   | 背面 | バックビュー |
| Shading    | 阴影 | シャドウ     |
| Center     | 中心 | 中心         |
| Axis       | 轴   |              |

## 参数详解

## 案例
