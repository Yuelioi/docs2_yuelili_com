# Liquify - 液化【暂无教程】

## 简述

可以轻松地在空间中产生失真

- 使用 10 种不同的工具扭曲图像
- 也可以为直接在图像上拖动的部分添加扭曲效果。

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-Liquify.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-Liquify_cn.png)

## 参数详解

### 工具

选择变形的工具

- 湍流  
  拖动区域不规则扭曲

- Shrink  
  向指针中心收缩

- 像素移动  
  拖动部分扭曲成直角

- 重建 恢复  
  已经扭曲的部分

![](https://cdn.yuelili.com/20211224181556.png)

### 扭曲网格

点击关键帧来为扭曲设置动画。

### 失真率

可以指定失真的强度，  
数值越大失真越大，数值越小越接近原图。

## 案例
