# Twirl - 旋转扭曲

## 简述

在指定旋转点的中心生成漩涡。可以创造一个似乎被吸进去的作品

### 关键词

效果：

类型：扭曲

控制基于：

控制范围：点控制、区域控制

生效范围：扭曲

## 效果展示

## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=37&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-Twirl.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-Twirl_cn.png)

## 参数详解

### 角度

指定旋转的方向和多少。  
正角是顺时针，负角是逆时针。

![](https://cdn.yuelili.com/20211224171629.png)

### 旋转扭曲半径

从中心点旋转的范围

## 案例
