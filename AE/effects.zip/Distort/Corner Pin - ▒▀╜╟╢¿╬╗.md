# Corner Pin - 边角定位

## 简述

低配 CC Power pin

可以使用图层的四个角自由变换它。

## 效果展示

## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=20&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-Corner_Pin.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-Corner_Pin_cn.png)

## 参数详解

### 左上/右上/左下/右下

可以移动图层的角来对应每个位置

![](https://cdn.yuelili.com/20211223021143.png)

## 案例

将图层插入图像并合并
