# CC Flo Motion - CC Flo运动

## 简述

允许你在一个图层上应用吸力效果。有点像黑洞？

## 效果展示

![](https://cdn.yuelili.com/20211222155557.png)

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-CC_Flo_Motion.png)

## 参数详解

Finer Controls 精细控制

勾选此框以减少扭曲。提高 20 倍精度

![](https://cdn.yuelili.com/20211222154103.png)

### Knot

吸入位置

### Amount

吸入数量

![](https://cdn.yuelili.com/20211222154416.png)

### Tile Edges 边缘平铺

图像边缘是否受到影响

![](https://cdn.yuelili.com/20211222154732.png)

### Antialiasing 抗锯齿

确定抗锯齿（图层边界的平滑度）。

### Falloff

设定变形的大小。数值越高，失真范围越广。

## 案例
