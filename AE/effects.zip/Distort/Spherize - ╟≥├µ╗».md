# Spherize - 球面化

## 简述

为图层添加不均匀度，可以像球面一样扭曲屏幕

## 效果展示

## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=104&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-Spherize.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-Spherize_cn.png)

## 参数详解

### Radius 半径

“球”的大小

### 球体中心

球的中心位置

###
