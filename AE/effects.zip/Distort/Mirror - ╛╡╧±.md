# Mirror - 镜像

## 简述

镜像图层，没啥好说的。

准确的说是镜像生效后的图层，所以放 2 个镜像，会生成 4 个物体

## 效果展示

## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=50&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-Mirror.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-Mirror_cn.png)

## 参数详解

### 反射中心

指定反射位置

### 反射角度

从[反射中心]，沿反射方向旋转图像。

![](https://cdn.yuelili.com/20211224172334.png)

## 案例
