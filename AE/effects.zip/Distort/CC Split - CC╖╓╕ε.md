# CC Split - CC分割

## 简述

指定两点之间撕开裂缝

## 效果展示

## 教程

<iframe src="https://player.bilibili.com/player.html?bvid=BV1e34y1X7Vj&page=69&high_quality=1" width="100%" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Distort-CC_Split.png)

| CC Split | CC 分割 |         |      |
| -------- | ------- | ------- | ---- |
|          |         | Point A | 点 A |
|          |         | Point B | 点 B |
|          |         | Split   | 分割 |

## 参数详解

### A / B 点

A 点和 B 点两点之间出现裂缝。

### Split 分割

确定要撕开多大口子

## 案例

使用 CC Split 添加动画，可以移动嘴巴（唇形同步）。
