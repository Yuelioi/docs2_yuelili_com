# VR Shphere To Plane - VR球面到平面

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Immersive-Video-VR_Shphere_To_Plane.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Immersive-Video-VR_Shphere_To_Plane_cn.png)
