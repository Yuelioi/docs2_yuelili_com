# VR DeNoise - VR降噪

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Immersive-Video-VR_DeNoise.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Immersive-Video-VR_DeNoise_cn.png)
