# VR Color Gradients - VR颜色渐变

## 简述

## 效果展示

## 教程

## 中英日对照

![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Immersive-Video-VR_Color_Gradients.png)![](https://mir.yuelili.com/wp-content/uploads/user/AE/effects/AE-Effects-Immersive-Video-VR_Color_Gradients_cn.png)
