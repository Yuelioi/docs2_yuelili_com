# 访问摄像机与灯光信息

使用[AEGP_PFInterfaceSuite](../aegps/aegp-suites.html)中提供的函数，插件可以访问它们所应用的层的相机和灯光信息；请看 Resizer 的例子。

也可以使用 AE_GeneralPlug.h 中的许多其他函数；很强大。
