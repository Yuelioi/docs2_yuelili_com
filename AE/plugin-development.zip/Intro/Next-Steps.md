# 下一步

现在已经了解了什么是插件，能做什么，以及 After Effects 如何与它们进行交互。

接下来，我们将介绍[特效插件的基本知识](../effect-basics/effect-basics.html) 。
