# 简介

欢迎来到 Adobe® After Effects® 软件开发工具包(SDK)

此文件正在不断地更新和迭代。最新版本参见<https://www.adobe.io/after-effects/>。

尽管我们已经尽力按逻辑顺序组织本文档，并提供了大量的交叉参考资料，但具体需求可能有所不同。根据关键词在本文档中进行搜索，往往可以找到你的答案。

更多信息，可以在 After Effects SDK 论坛上得到了解答。[After Effects SDK Forum](https://community.adobe.com/t5/after-effects/bd-p/after-effects?page=1&sort=latest_replies&filter=all&topics=label-sdk)

善用搜索，如果你的问题还没有被回答，请发表新问题。
