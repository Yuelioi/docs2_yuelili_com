# 名词解释

## 缩写以及临时翻译名称

如果有问题方便进行批量更改

AEGP: AE 常规插件 (After Effects General Plug-ins)
AEIO: AE 输入输出接口 (After Effects General Input/Output)
PiPL: 效果属性列表 (Plug-In Property Lists)
ECP: 效果控制面板(Effect Controls panel)
ECW: 插件面板(Effect Controls Window)
MFR: 多帧渲染 Multi-Frame Rendering
arb: 任意(Arbitrary)
PICA:插件组件架构(Plug-In Component Architecture)

Artisans:

Selectors 入口指令篇
(Se)Command Selectors: Ae 入口指令
(Se)Frame Selectors: 帧相关入口指令
(Se)Global Selectors: 全局入口指令
(Se)Selector/Selectors: 入口指令
(Se)Sequence Selectors: 序列入口指令

basic non-SmartFX effect: 基础非智能特效插件
callback/callback function: 回调函数
flag: 标志/开关/标签
fields: 字段/结构体成员/成员变量
Entry Points 入口函数

Re-Entrancy: 重入

flatten and unflatten :展平/非展平
flat data 线性数据
flatten 线性储存的(adj)/线性储存转换(v)
flatten sequence data 把序列数据进行线性储存转换
frame-specific data 特定帧的数据
function suites 函数套件
Pointer 指针
handle 句柄
importer 导入器
output formats 输出版式
relative origin 相关源(信息)
sample projects 范例工程
SmartFX effect 智能特效插件
thumb 时间标杆
unflatten 非线性储存的(adj)/解线性储存转换(v)
user interface elements UI 元素
Accessor Macros 访问器宏
checkout:签出

effect: 效果/插件
Compute Cache: 计算缓存
receipt :凭证

transfer mode: 混合模式
ampling routine:例程
scanline:扫描线

Parameter:参数
downsample factor:降频采样系数
