Resource - SkeletonPiPL.r 用于修改 匹配名 目录等信息

PIPL : Plug-In Property Lists(插件属性列表)

About: 关于, 插件的关于信息

EffectMain: 根据用户操作, 进入不同处理函数

GlobalSetup: 初始化插件

ParamsSetup: 插件UI初始化

mySimpleGainFunc: 基于颜色深度 执行不同函数

Render: 渲染, 在首次应用插件,以及更改插件参数值时执行