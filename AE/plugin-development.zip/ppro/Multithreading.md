# 多线程

您可能已经注意到这个标志： `PF_OutFlag2_PPRO_DO_NOT_CLONE_SEQUENCE_DATA_FOR_RENDER`. 我们建议不要设置此标志，因为已发现它会导致参数 UI 问题。
