# Premiere Elements

# Premiere Elements

Premiere Elements(但不是 Premiere Pro)为每个效果显示视觉图标。你需要为你的效果提供图标，否则你的效果将显示一个空的黑色图标，甚至在 Premiere Elements 8 中会有更糟糕的行为。

这些图标是 60x45 的 PNG 文件，放在这里。

[程序文件]AdobeAdobe Premiere Elements [版本]Plug-inCommonEffectPreviews

文件名应该是你在[PiPL 资源](../intro/pipl-resources.html)中指定的效果的匹配名称，前缀为 "AE"。因此，如果匹配名称是 "MatchName"，那么文件名应该是 "AE.MatchName.png"
