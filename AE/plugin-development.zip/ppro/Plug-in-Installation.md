# 插件安装

使用这里描述的通用插件文件夹。[应该在哪安装插件](../intro/where-installers-should-put-plug-ins.html) 。

如果试图只把一个效果插件安装到 Premiere Pro 的插件目录中，你会惊讶地发现，当你通过 Adobe Media Encoder(一个完全独立的应用程序)导出磁盘时，你的效果不会被渲染。

哦，你还会错过在 Premiere Pro 和 After Effects 之间的项目交换和复制/粘贴。
