# Modifier总览

## Description

https://docs.blender.org/api/master/bpy.types.Modifier.html
