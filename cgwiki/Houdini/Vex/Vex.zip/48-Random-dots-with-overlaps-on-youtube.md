# youtube 上有重叠的随机点

作为一项实验，我录制了一个视频教程，将其提升到一个新的水平，回答了我上面提出的一些问题。你可以在这里找到它：

<https://www.youtube.com/watch?v=XZTFBRj--CY>
