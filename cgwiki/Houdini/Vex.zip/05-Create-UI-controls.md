创建 UI 控件
假设你有这个：


```
@Cd.r = sin( @P.x *  5  );
```


但是您想将 5 更改为另一个数字。您可以继续使用不同的数字更改代码，或将 5 替换为 ch('scale') ：


```
@Cd.r = sin( @P.x *  ch('scale')   );
```


ch() 告诉 Houdini 去寻找一个通道，也就是 Houdini 所说的 UI 组件，通常是一个滑块。点击文本编辑器右侧的小插头图标，Houdini 扫描 vex 代码，意识到您引用了一个尚不存在的频道，并在 wrangle UI 的底部创建了一个名为“scale”的频道。开始滑动它，您会看到颜色更新。

您可以使用多种渠道类型。ch() 和 chf() 都创建了一个浮动通道。对于其他人：

```

// An int channel
i@myint = chi('myint');

// A vector channel
v@myvector = chv('awesome');

// A ramp channel
f@foo = chramp('myramp',@P.x);
```


最后一个非常方便，在一行中您可以读取一个值 (@Px)，通过 UI ramp 小部件重新映射它，并将其提供给@foo。我最终在我的设置中使用了大量这些。它假定输入值在 0-1 范围内，您通常必须在馈送到斜坡之前调整这些值。拟合函数拟合（值、oldmin、oldmax、newmin、newmax）。例如，在 -0.5 和 6 之间重新映射 X，然后使用渐变将这些值输入红色通道：

```

float tmp = fit(@P.x, -0.5,6,0,1);
@Cd.r = chramp('myramp',tmp);
```


但为什么要停在那里呢？使用 UI 滑块定义起点和终点！

```

float min = ch('min');
float max = ch('max');
float tmp = fit(@P.x, min,max,0,1);
@Cd = 0;  // lazy way to reset the colour to black before the next step
@Cd.r = chramp('myramp',tmp);
```
