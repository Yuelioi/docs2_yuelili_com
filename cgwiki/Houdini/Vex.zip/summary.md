1 Create a new attribute
2 Get existing attribute values
3 Implicit vs explicit attribute type
4 Parallel processing, part 1
5 Create UI controls
6 Customise the UI elements
7 Common functions
8 Built-in attributes
9 Example： Random delete points by threshold
10 Example： Wave deformer
11 Attributes vs variables
12 Example： Rotation
12.1 Rotate a single point with sin and cos
12.2 Rotate geometry with sin and cos
12.3 Rotate into a twirl or spiral
12.4 Rotate with a matrix
12.5 Rotate prims around an edge
12.6 Rotate prims around an edge, alternate version
12.7 Normalizing vectors
12.1 Rotate a single point with sin and cos
12.2 Rotate geometry with sin and cos
12.3 Rotate into a twirl or spiral
12.4 Rotate with a matrix
12.5 Rotate prims around an edge
12.6 Rotate prims around an edge, alternate version
12.7 Normalizing vectors
13 Wrangles vs hscript vs vops vs everything else
14 Mixing vex and vops with snippets
15 Get values from other points, other geo
16 Blurring attributes with vex and point clouds
17 Parallel processing part 2
17.1 That's hard to read, summarise please
17.1 That's hard to read, summarise please
18 Get attributes from other inputs
19 Arrays
20 Search an array with find
21 Access group names procedurally in vex
22 Random colour groups with vex
23 Solver sop and wrangles for simulation
24 Solver and wrangle for branching structures
25 Get transform of objects with optransform
26 optransform to do a motion control style camera
27 More on rotation Orient, Quaternions, Matricies, Offsets, stuff
28 Convert N to Orient with dihedral
29 Convert N and Up to Orient with maketransform
30 Copies to sit on a surface, with random rotation, with orient
31 Combine quaternions with qmultiply
32 Remove points that don't have normals directly along an axis
33 Scaling with vex and matrices
34 Generate a disk of vectors perpendicular to a vector
35 xyzdist to get info about the closest prim to a position
36 Rubiks cube
37 Sliding puzzle
38 Vex vs Vops
39 Vex snippet cheat sheet
40 Vex includes
41 Spherical and linear gradients
42 Spiral along curve
43 Linear vertex or find the starting point on every curve
44 Query image width and height
45 Ensure unique names
46 Distort colour with noise and primuv
47 Random dot patterns
48 Random dots with overlaps on youtube
49 Further learning
