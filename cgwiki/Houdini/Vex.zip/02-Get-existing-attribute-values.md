获取现有属性值
你想让 myvector 从点位置获取它的值吗？


```
v@myvector=@P;
```


@ 符号用于获取和设置属性。您在几何电子表格中看到的所有属性，您都可以通过在其名称前加上 @ 来访问它们。

你想要它的 1.5 倍 N？


```
v@myvector=@N*1.5;
```


要访问矢量或颜色的单个属性，请使用@attribute.channel。例如，只获取每个点的 y 值并将其分成两半：


```
@foo=@P.y / 2;
```


设置它是相似的。例如，将每个点的红色通道设置为 x 位置的两倍的正弦值：


```
@Cd.r = sin( @P.x * 2 );
```


像 Cd 或 P 这样的矢量属性可以让你以多种方式引用组件，使用任何方便的方式。分量可以是 r/g/b、x/y/z、[0]/[1]/[2]。


```
// These all do the same thing, set the first component of the vector:
@Cd.r = 1;
@Cd.x = 1;
@Cd[0] = 1;

// As are these, all setting the third component:

@P.z = 6;
@P.b = 6;
@P[2] = 6;
```
