内置属性
您可以使用一些内置变量，查看它们的最简单方法是放下一个点 vop，然后查看全局参数。下面是比较常见的：

@ptnum - 点号
@numpt - 总点数
@Time - 当前时间，以秒为单位
@Frame - 当前帧
@primnum - 原始 ID
@numprim - 图元总数