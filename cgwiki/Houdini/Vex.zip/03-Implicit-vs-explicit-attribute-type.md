隐式与显式属性类型
请注意，wrangles 隐含地知道某些常见的属性类型（@P、@Cd、@N、@v、@orient、@id、@name 等），但如果您有自己的属性，Houdini 将假设它是一个浮点数，除非否则，很容易犯错误。

为确保 Houdini 做正确的事情，请在类型前添加。例如，您已将 @mycolour 设置为矢量，并尝试在争论中使用它：


```
// BAD
@Cd = @mycolour; // This will treat it as a float and only read the first value (ie, just the red channel of @mycolour)

// GOOD
@Cd = v@mycolour; // Explicitly tells the wrangle that its a vector.

```

我总是忘记这样做，对我的争吵大喊大叫，最后记得在我的属性名称前加上“v”。毫无疑问，您