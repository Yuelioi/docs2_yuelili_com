进一步学习
JoyOfVex如果您还没有这样做的话。

Juraj Tomori 写了一个很棒的指南，现在就去读吧：https ://github.com/jtomori/vex_tutorial

Sidefx 有一个与此类似的备忘单，但它假定了很多先验知识。如果你已经把它写到页面下方那么你可能已经准备好了，它指出了很多我已经忽略的边缘情况：

http://www.sidefx.com/docs/houdini/vex/snippets

odforce 上的“蜜蜂和炸弹”线程是一堆实用的（大概）视觉示例；许多自包含的循环动画（大部分）在 vex 中创建。请务必检查最后的线程，Robert Hodgin 已经清理了该线程中的大部分早期设置，以便它们在 H16 中正常工作：

http://forums.odforce.net/topic/24056-learning-vex-via-animated-gifs-bees-bombs/

Ryoji CG 有一个方便的争论片段集合：

https://sites.google.com/site/fujitarium/Houdini/sop/wrangle

wrangle workshop 还不错，但如果我要批评移动有点慢（我也超级不耐烦，更喜欢文字而不是视频，但那就是我......）

https://vimeo.com/67677051

Shadertoy 是激发灵感的好地方。代码并不麻烦，很多文件使用的技术并不直接映射到 Houdini，但即便如此，查看您可能想要实现的技术的可视化示例还是很方便的，核心算法通常可以是很容易重新映射到 vex：

https://www.shadertoy.com

处理、各种 javascript 图形库、较旧的 actionscript，都非常适合从中窃取创意。

https://processing.org/
http://threejs.org/
http://www.bit-101.com/blog/