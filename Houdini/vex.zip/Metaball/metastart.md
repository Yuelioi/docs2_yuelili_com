# metastart

`int metastart(string filename, vector p)`

然后你可以使用[metanext](metanext.html) () ("在 metastart()函数返回的 metaball 列表中迭代到下一个 metaball。"）来移动句柄到下一个元宝进行评估，而[metaimport](metaimport.html) ("一旦你用metastart和metanext得到一个元宝的句柄，你就可以用metaimport查询元宝的属性。")来查询元宝的属性。

元宝

[metaimport](metaimport.html)

[metamarch](metamarch.html)

[metanext](metanext.html)

[metastart](metastart.html)

[metaweight](metaweight.html)
