# metaweight

`float metaweight(<geometry>geometry, vector p)`

返回 p 位置的几何体的元权重。这是评估该位置的几何体中所有元球的结果。通常这是其数值的总和，但是元表达式可以改变这一点。

元宝

[metaimport](metaimport.html)

[metamarch](metamarch.html)

[metanext](metanext.html)

[metastart](metastart.html)

[metaweight](metaweight.html)
