# geoself

`int geoself()`

返回当前几何体的句柄，适用于几何体创建操作。

利用

[geoself](geoself.html)
