# rgbtohsv

`vector rgbtohsv(vector rgb)`

`vector rgbtohsv(float r, float g, float b)`

将 RGB 颜色空间转换为 HSV 颜色空间。一个代表 HSV 颜色的向量被返回。色调将在 0 到 1 的范围内。

颜色

[blackbody](blackbody.html)

[colormap](colormap.html)

[ctransform](ctransform.html)

[environment](environment.html)

[hsvtorgb](hsvtorgb.html)

[luminance](luminance.html)

[ocio_activedisplays](ocio_activedisplays.html)

[ocio_activeviews](ocio_activeviews.html)

[ocio_import](ocio_import.html)

[ocio_transform](ocio_parsecolorspace.html)

[ocio_roles](ocio_roles.html)

[ocio_spaces](ocio_spaces.html)

[ocio_transform](ocio_transform.html)

[rawcolormap](rawcolormap.html)

[rgbtohsv](rgbtohsv.html)

[rgbtoxyz](rgbtoxyz.html)

[xyztorgb](xyztorgb.html)

|转换

[ctransform](ctransform.html)

[degrees](degrees.html)

[hsvtorgb](hsvtorgb.html)

[luminance](luminance.html)

[radians](radians.html)

[rgbtohsv](rgbtohsv.html)

[rgbtoxyz](rgbtoxyz.html)

[xyztorgb](xyztorgb.html)
