# iplanename

[cop](../contexts/cop.html)

`string iplanename(int opinput, int planeindex)`

## Arguments

`opinput`

Context(s) 要读取的输入号码，从 0 开始。例如，第一个输入是 0，第二个输入是 1，以此类推。

## Returns

由给定输入的 planeindex 指定的平面名称（例如，"C"，"A"）。

输入平面

[iaspect](iaspect.html)

[ichname](ichname.html)

[iend](iend.html)

[iendtime](iendtime.html)

[ihasplane](ihasplane.html)

[inumplanes](inumplanes.html)

[iplaneindex](iplaneindex.html)

[iplanename](iplanename.html)

[iplanesize](iplanesize.html)

[irate](irate.html)

[istart](istart.html)

[istarttime](istarttime.html)

[ixres](ixres.html)

[iyres](iyres.html)
