# planesize

[cop](../contexts/cop.html)

`int planesize(int planeindex)`

Context(s) 返回平面中的组件数量（标量平面为 1，矢量平面最多为 4）。如果索引超出范围则返回 0。

输出平面

[alphaname](alphaname.html)

[bumpname](bumpname.html)

[chname](chname.html)

[colorname](colorname.html)

[depthname](depthname.html)

[hasplane](hasplane.html)

[lumname](lumname.html)

[maskname](maskname.html)

[normalname](normalname.html)

[planeindex](planeindex.html)

[planename](planename.html)

[planesize](planesize.html)

[pointname](pointname.html)

[velocityname](velocityname.html)
