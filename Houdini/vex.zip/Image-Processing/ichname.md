# ichname

[cop](../contexts/cop.html)

`string ichname(int inputnum, int plane_index, int component_index)`

Context(s) 返回一个平面的某个组件的组件名称（例如，"r "或 "x"）。

输入平面

[iaspect](iaspect.html)

[ichname](ichname.html)

[iend](iend.html)

[iendtime](iendtime.html)

[ihasplane](ihasplane.html)

[inumplanes](inumplanes.html)

[iplaneindex](iplaneindex.html)

[iplanename](iplanename.html)

[iplanesize](iplanesize.html)

[irate](irate.html)

[istart](istart.html)

[istarttime](istarttime.html)

[ixres](ixres.html)

[iyres](iyres.html)
