# planename

[cop](../contexts/cop.html)

`string planename(int planeindex)`

Context(s) 返回由索引指定的平面名称（例如，"C"，"A"）。

输出平面

[alphaname](alphaname.html)

[bumpname](bumpname.html)

[chname](chname.html)

[colorname](colorname.html)

[depthname](depthname.html)

[hasplane](hasplane.html)

[lumname](lumname.html)

[maskname](maskname.html)

[normalname](normalname.html)

[planeindex](planeindex.html)

[planename](planename.html)

[planesize](planesize.html)

[pointname](pointname.html)

[velocityname](velocityname.html)
