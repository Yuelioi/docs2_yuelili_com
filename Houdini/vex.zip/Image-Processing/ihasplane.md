# ihasplane

[cop](../contexts/cop.html)

`int ihasplane(int opinput, string planename)`

Context(s) 如果指定的输入有一个名为`planename'的平面，返回 1。输入数字从 0 开始。

## Arguments

`opinput`

要读取的输入号码，从 0 开始。例如，第一个输入是 0，第二个输入是 1，以此类推。

输入平面

[iaspect](iaspect.html)

[ichname](ichname.html)

[iend](iend.html)

[iendtime](iendtime.html)

[ihasplane](ihasplane.html)

[inumplanes](inumplanes.html)

[iplaneindex](iplaneindex.html)

[iplanename](iplanename.html)

[iplanesize](iplanesize.html)

[irate](irate.html)

[istart](istart.html)

[istarttime](istarttime.html)

[ixres](ixres.html)

[iyres](iyres.html)
