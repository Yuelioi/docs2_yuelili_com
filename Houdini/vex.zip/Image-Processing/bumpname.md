# bumpname

[cop](../contexts/cop.html)

`string bumpname()`

Context(s) 返回凸起平面的默认名称（正如它在合成器首选项中显示的那样）。使用这个名称而不是硬编码默认名称可以使你的代码更容易移植。默认是 "B"。

输出平面

[alphaname](alphaname.html)

[bumpname](bumpname.html)

[chname](chname.html)

[colorname](colorname.html)

[depthname](depthname.html)

[hasplane](hasplane.html)

[lumname](lumname.html)

[maskname](maskname.html)

[normalname](normalname.html)

[planeindex](planeindex.html)

[planename](planename.html)

[planesize](planesize.html)

[pointname](pointname.html)

[velocityname](velocityname.html)
