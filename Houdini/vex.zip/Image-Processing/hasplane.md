# hasplane

[cop](../contexts/cop.html)

`int hasplane(string planename)`

Context(s) 如果参数所指定的平面存在于这个 COP 中，则返回 1。

输出平面

[alphaname](alphaname.html)

[bumpname](bumpname.html)

[chname](chname.html)

[colorname](colorname.html)

[depthname](depthname.html)

[hasplane](hasplane.html)

[lumname](lumname.html)

[maskname](maskname.html)

[normalname](normalname.html)

[planeindex](planeindex.html)

[planename](planename.html)

[planesize](planesize.html)

[pointname](pointname.html)

[velocityname](velocityname.html)
