# irate

[cop](../contexts/cop.html)

`float irate(int opinput)`

## Arguments

`opinput`

Context(s) 要读取的输入号码，从 0 开始。例如，第一个输入是 0，第二个输入是 1，以此类推。

## Returns

指定输入的帧率。

输入平面

[iaspect](iaspect.html)

[ichname](ichname.html)

[iend](iend.html)

[iendtime](iendtime.html)

[ihasplane](ihasplane.html)

[inumplanes](inumplanes.html)

[iplaneindex](iplaneindex.html)

[iplanename](iplanename.html)

[iplanesize](iplanesize.html)

[irate](irate.html)

[istart](istart.html)

[istarttime](istarttime.html)

[ixres](ixres.html)

[iyres](iyres.html)
