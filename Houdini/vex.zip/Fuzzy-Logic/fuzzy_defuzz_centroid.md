# fuzzy_defuzz_centroid

`float fuzzy_defuzz_centroid(float aggregated_membership[], float min_value, float max_value)`

返回一个脆性值，给定一个脆性值的范围，以及一个输出变量的聚合成员函数。

模糊的

[fuzzify](fuzzify.html)

[fuzzy_and](fuzzy_and.html)

[fuzzy_defuzz_centroid](fuzzy_defuzz_centroid.html)

[fuzzy_nand](fuzzy_nand.html)

[fuzzy_nor](fuzzy_nor.html)

[fuzzy_not](fuzzy_not.html)

[fuzzy_nxor](fuzzy_nxor.html)

[fuzzy_or](fuzzy_or.html)

[fuzzy_xor](fuzzy_xor.html)
