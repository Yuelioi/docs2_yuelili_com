# Branch
Interval 模式

---

**Inertval**

Frequency：频率（整体分布密度）

Count：数量（每一叉的数量）

Sweep：多叉交错旋转（以每叉自身为中心旋转）

Spread：展开（每一叉舒展开来，不抱团）

Spiral：螺旋（旋转）

![speedtree-20220416110058](https://image-1300893378.cos.ap-shanghai.myqcloud.com/docs/speedtree/SpeedTree-20220416110058.png)